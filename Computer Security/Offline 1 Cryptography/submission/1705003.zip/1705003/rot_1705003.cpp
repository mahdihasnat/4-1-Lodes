
// left circular shift of unsigned int
#define RotWord(x) (((x) << 8) | ((x) >> 24))