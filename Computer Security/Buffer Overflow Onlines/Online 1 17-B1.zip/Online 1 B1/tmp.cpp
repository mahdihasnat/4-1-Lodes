#include<bits/stdc++.h>

using namespace std;

int main()
{
    int b = 0x111111;
    int a = 21 - b;
    unsigned int x = a;
    cout<<" signed a = "<<a<<"\n";
    cout<<" unsigned a = "<<x<<"\n";
    cout<<" b = "<<b<<"\n";
}