#ifndef COMMON_H
#define COMMON_H

#include <GL/glut.h>
#include <bits/stdc++.h>
using namespace std;



#include "1705003_constants.h"



#endif /* COMMON_H */
