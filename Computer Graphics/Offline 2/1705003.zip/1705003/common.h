#ifndef COMMON_H
#define COMMON_H

const double EPS = 1e-5; 
#define PI 3.14159265358979323846


#endif /* COMMON_H */
